plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.vlessclient"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.vlessclient"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    // Native sing-box engine; JitPack fetches the matching libbox.aar at build time.
    implementation("com.github.singbox-android:libbox:1.14.0")
}

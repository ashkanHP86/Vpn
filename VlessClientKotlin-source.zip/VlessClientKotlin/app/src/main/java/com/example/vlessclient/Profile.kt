package com.example.vlessclient

import android.util.Base64
import org.json.JSONObject
import java.net.URI
import java.net.URLDecoder
import java.nio.charset.StandardCharsets

/** Parses share links from the supplied HTML client and converts them to sing-box outbounds. */
data class Profile(
    val raw: String,
    val name: String,
    val host: String,
    val port: Int,
    val outbound: JSONObject,
) {
    fun config(): String {
        val dns = JSONObject().put("servers", org.json.JSONArray()
            .put(JSONObject().put("tag", "remote-dns").put("address", "tls://1.1.1.1").put("detour", "proxy")))
            .put("final", "remote-dns").put("strategy", "prefer_ipv4")
        val tun = JSONObject()
            .put("type", "tun").put("tag", "tun-in")
            .put("address", org.json.JSONArray().put("172.19.0.1/30").put("fdfe:dcba:9876::1/126"))
            .put("mtu", 9000).put("auto_route", true).put("strict_route", true)
            .put("stack", "system").put("sniff", true)
        val route = JSONObject().put("auto_detect_interface", false).put("final", "proxy")
        return JSONObject()
            .put("log", JSONObject().put("level", "warn"))
            .put("dns", dns)
            .put("inbounds", org.json.JSONArray().put(tun))
            .put("outbounds", org.json.JSONArray().put(outbound).put(JSONObject().put("type", "direct").put("tag", "direct")))
            .put("route", route).toString()
    }

    companion object {
        fun parseSubscription(input: String): List<Profile> {
            var text = input.trim()
            if (text.isEmpty()) return emptyList()
            if (!text.contains("://")) {
                val decoded = try { String(Base64.decode(text.replace(Regex("\\s+"), ""), Base64.DEFAULT), StandardCharsets.UTF_8) } catch (_: Exception) { "" }
                if (decoded.contains("://")) text = decoded
            }
            return text.lineSequence().mapNotNull { parse(it.trim()) }.toList()
        }

        fun parse(link: String): Profile? = try {
            when {
                link.startsWith("vmess://", true) -> parseVmess(link)
                link.startsWith("vless://", true) -> parseUri(link, "vless")
                link.startsWith("trojan://", true) -> parseUri(link, "trojan")
                link.startsWith("hysteria2://", true) || link.startsWith("hy2://", true) -> parseUri(link, "hysteria2")
                link.startsWith("tuic://", true) -> parseUri(link, "tuic")
                link.startsWith("ss://", true) -> parseShadowsocks(link)
                else -> null
            }
        } catch (_: Exception) { null }

        private fun parseVmess(link: String): Profile? {
            val raw = link.removePrefix("vmess://")
            val json = JSONObject(String(Base64.decode(raw, Base64.DEFAULT), StandardCharsets.UTF_8))
            val host = json.optString("add").takeIf { it.isNotBlank() } ?: return null
            val port = json.optInt("port", 0).takeIf { it in 1..65535 } ?: return null
            val uuid = json.optString("id").takeIf { it.isNotBlank() } ?: return null
            val outbound = JSONObject().put("type", "vmess").put("tag", "proxy")
                .put("server", host).put("server_port", port).put("uuid", uuid)
                .put("security", json.optString("scy", "auto"))
                .put("alter_id", json.optInt("aid", 0))
            val tls = json.optString("tls").equals("tls", true)
            if (tls) outbound.put("tls", tlsObject(json.optString("sni", host), json.optString("fp", "chrome"), false, "", ""))
            val net = json.optString("net", "tcp").lowercase()
            if (net == "ws") outbound.put("transport", JSONObject().put("type", "ws").put("path", json.optString("path", "/"))
                .put("headers", JSONObject().put("Host", json.optString("host", host))))
            if (net == "grpc") outbound.put("transport", JSONObject().put("type", "grpc").put("service_name", json.optString("path")))
            return Profile(link, json.optString("ps", host), host, port, outbound)
        }

        private fun parseUri(link: String, protocol: String): Profile? {
            val uri = URI(link)
            val host = uri.host?.removePrefix("[")?.removeSuffix("]") ?: return null
            val port = uri.port.takeIf { it in 1..65535 } ?: return null
            val query = parseQuery(uri.rawQuery.orEmpty())
            val fragment = uri.rawFragment?.let { decode(it) }?.takeIf { it.isNotBlank() } ?: host
            val user = uri.rawUserInfo?.substringBefore(':')?.let { decode(it) }.orEmpty()
            val password = uri.rawUserInfo?.substringAfter(':', "")?.let { decode(it) }.orEmpty()
            val out = JSONObject().put("type", protocol).put("tag", "proxy").put("server", host).put("server_port", port)
            when (protocol) {
                "vless" -> {
                    if (user.isBlank()) return null
                    out.put("uuid", user).put("flow", query["flow"].orEmpty()).put("packet_encoding", "xudp")
                    val security = query["security"].orEmpty()
                    if (security == "tls" || security == "reality") {
                        val reality = security == "reality"
                        out.put("tls", tlsObject(query["sni"] ?: query["serverName"] ?: host, query["fp"] ?: "chrome", reality, query["pbk"].orEmpty(), query["sid"].orEmpty()))
                    }
                    addTransport(out, query, host)
                }
                "trojan" -> {
                    if (user.isBlank()) return null
                    out.put("password", user)
                    out.put("tls", tlsObject(query["sni"] ?: host, query["fp"] ?: "chrome", false, "", ""))
                    addTransport(out, query, host)
                }
                "hysteria2" -> {
                    val pwd = if (user.isNotBlank()) user else password
                    if (pwd.isBlank()) return null
                    out.put("password", pwd).put("tls", tlsObject(query["sni"] ?: host, query["fp"] ?: "chrome", false, "", ""))
                    if (query["obfs"] == "salamander") out.put("obfs", JSONObject().put("type", "salamander").put("password", query["obfs-password"].orEmpty()))
                }
                "tuic" -> {
                    if (user.isBlank()) return null
                    out.put("uuid", user).put("password", password)
                    out.put("tls", tlsObject(query["sni"] ?: host, query["fp"] ?: "chrome", false, "", ""))
                    out.put("congestion_control", query["congestion_control"] ?: "bbr")
                }
            }
            return Profile(link, fragment, host, port, out)
        }

        private fun parseShadowsocks(link: String): Profile? {
            val uri = URI(link)
            var info = uri.rawUserInfo.orEmpty()
            var host = uri.host
            var port = uri.port
            if (host == null) {
                val decoded = try { String(Base64.decode(link.removePrefix("ss://").substringBefore('#').substringBefore('?'), Base64.DEFAULT), StandardCharsets.UTF_8) } catch (_: Exception) { "" }
                val parsed = URI("ss://$decoded")
                info = parsed.rawUserInfo.orEmpty(); host = parsed.host; port = parsed.port
            }
            host = host ?: return null
            if (port !in 1..65535) return null
            val decodedInfo = try { String(Base64.decode(info, Base64.DEFAULT), StandardCharsets.UTF_8) } catch (_: Exception) { info }
            val method = decodedInfo.substringBefore(':')
            val password = decodedInfo.substringAfter(':', "")
            if (method.isBlank() || password.isBlank()) return null
            val out = JSONObject().put("type", "shadowsocks").put("tag", "proxy").put("server", host)
                .put("server_port", port).put("method", method).put("password", password)
            return Profile(link, uri.rawFragment?.let(::decode) ?: host, host, port, out)
        }

        private fun addTransport(out: JSONObject, q: Map<String, String>, host: String) {
            when (q["type"]?.lowercase()) {
                "ws" -> out.put("transport", JSONObject().put("type", "ws").put("path", q["path"] ?: "/")
                    .put("headers", JSONObject().put("Host", q["host"] ?: host)))
                "grpc" -> out.put("transport", JSONObject().put("type", "grpc").put("service_name", q["serviceName"] ?: q["service_name"] ?: ""))
                "httpupgrade" -> out.put("transport", JSONObject().put("type", "httpupgrade").put("path", q["path"] ?: "/").put("host", q["host"] ?: host))
                "h2", "http" -> out.put("transport", JSONObject().put("type", "http").put("path", q["path"] ?: "/").put("host", org.json.JSONArray().put(q["host"] ?: host)))
            }
        }

        private fun tlsObject(serverName: String, fingerprint: String, reality: Boolean, publicKey: String, shortId: String): JSONObject {
            val tls = JSONObject().put("enabled", true).put("server_name", serverName)
                .put("utls", JSONObject().put("enabled", true).put("fingerprint", fingerprint))
            if (reality) tls.put("reality", JSONObject().put("enabled", true).put("public_key", publicKey).put("short_id", shortId))
            return tls
        }

        private fun parseQuery(query: String): Map<String, String> = query.split('&').filter { it.isNotBlank() }.associate {
            val parts = it.split('=', limit = 2); decode(parts[0]) to decode(parts.getOrElse(1) { "" })
        }
        private fun decode(s: String): String = URLDecoder.decode(s.replace("+", "%2B"), "UTF-8")
    }
}

package com.example.vlessclient

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("client", MODE_PRIVATE) }
    private val profiles = mutableListOf<Profile>()
    private var selected = 0
    private var connected = false
    private var connecting = false
    private lateinit var status: TextView
    private lateinit var clock: TextView
    private lateinit var ping: TextView
    private lateinit var data: TextView
    private lateinit var speed: TextView
    private lateinit var serverButton: Button
    private lateinit var connectButton: Button
    private lateinit var input: EditText
    private lateinit var message: TextView
    private val worker = Executors.newSingleThreadExecutor()

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != NativeVpnService.EVENT) return
            connected = intent.getBooleanExtra("connected", false)
            connecting = intent.getBooleanExtra("connecting", false)
            status.text = intent.getStringExtra("status") ?: if (connected) "متصل" else "قطع"
            connectButton.text = when { connecting -> "در حال اتصال…"; connected -> "قطع اتصال"; else -> "اتصال" }
            connectButton.isEnabled = !connecting
            val rx = intent.getLongExtra("rxRate", 0L)
            val tx = intent.getLongExtra("txRate", 0L)
            data.text = "دریافت برنامه: ${formatBytes(intent.getLongExtra("rx", 0L))}  •  ارسال برنامه: ${formatBytes(intent.getLongExtra("tx", 0L))}"
            speed.text = "↓ ${formatRate(rx)}/s     ↑ ${formatRate(tx)}/s"
            clock.text = intent.getStringExtra("elapsed") ?: "00:00:00"
            ping.text = intent.getStringExtra("ping") ?: "TCP latency: —"
            status.setTextColor(if (connected) 0xFF30D158.toInt() else 0xFFFF453A.toInt())
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadProfiles()
        buildUi()
        val filter = IntentFilter(NativeVpnService.EVENT)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(receiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(receiver, filter)
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(16), dp(22), dp(20))
            setBackgroundColor(0xFF000000.toInt())
            gravity = Gravity.CENTER_HORIZONTAL
        }
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; orientation = LinearLayout.HORIZONTAL }
        top.addView(TextView(this).apply { text = "VLESS Client"; textSize = 28f; setTextColor(-1); typeface = android.graphics.Typeface.DEFAULT_BOLD }, LinearLayout.LayoutParams(0, -2, 1f))
        val settings = button("تنظیمات") { showSettings() }
        top.addView(settings)
        root.addView(top)
        root.addView(space(26))

        val ring = FrameLayout(this).apply {
            val size = (resources.displayMetrics.widthPixels * .70f).toInt().coerceAtMost(dp(330))
            layoutParams = LinearLayout.LayoutParams(size, size)
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(0xFF101012.toInt()); setStroke(dp(9), 0xFF303034.toInt())
            }
            isClickable = true
            setOnClickListener { toggleConnection() }
        }
        val center = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        clock = TextView(this).apply { text = "00:00:00"; textSize = 36f; setTextColor(-1); typeface = android.graphics.Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER }
        status = TextView(this).apply { text = "قطع"; textSize = 18f; setTextColor(0xFFFF453A.toInt()); gravity = Gravity.CENTER }
        ping = TextView(this).apply { text = "TCP latency: —"; textSize = 13f; setTextColor(0xFF8E8E93.toInt()); gravity = Gravity.CENTER }
        center.addView(clock); center.addView(status); center.addView(ping)
        ring.addView(center, FrameLayout.LayoutParams(-1, -1))
        root.addView(ring)
        root.addView(space(24))
        data = TextView(this).apply { text = "دریافت برنامه: 0 B • ارسال برنامه: 0 B"; textSize = 13f; setTextColor(0xFF8E8E93.toInt()); gravity = Gravity.CENTER }
        speed = TextView(this).apply { text = "↓ 0 B/s     ↑ 0 B/s"; textSize = 14f; setTextColor(0xFF8E8E93.toInt()); gravity = Gravity.CENTER }
        root.addView(data); root.addView(space(6)); root.addView(speed); root.addView(space(18))
        serverButton = button("انتخاب سرور") { chooseServer() }
        root.addView(serverButton, LinearLayout.LayoutParams(-1, dp(52)))
        root.addView(space(10))
        connectButton = button("اتصال") { toggleConnection() }.apply {
            setBackgroundColor(-1); setTextColor(0xFF000000.toInt()); textSize = 18f
        }
        root.addView(connectButton, LinearLayout.LayoutParams(-1, dp(56)))
        root.addView(space(16))
        message = TextView(this).apply { text = "آمار نمایش‌داده‌شده از شمارنده‌های واقعی سیستم خوانده می‌شود؛ ممکن است همه ترافیک عبوری VPN را پوشش ندهد."; textSize = 12f; setTextColor(0xFF636366.toInt()); gravity = Gravity.CENTER }
        root.addView(message)
        setContentView(ScrollView(this).apply { setBackgroundColor(0xFF000000.toInt()); addView(root) })
        refreshServerButton()
    }

    private fun showSettings() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(10), dp(18), dp(4)) }
        input = EditText(this).apply {
            hint = "لینک اشتراک یا لینک‌های vless://، vmess://…"
            setHintTextColor(0xFF77777D.toInt()); setTextColor(-1); textSize = 13f
            minLines = 4; gravity = Gravity.TOP; setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(0xFF1C1C1E.toInt())
        }
        box.addView(input, LinearLayout.LayoutParams(-1, dp(140)))
        val dlg = android.app.AlertDialog.Builder(this).setTitle("اشتراک و سرورها").setView(box)
            .setPositiveButton("وارد کردن") { _, _ -> importSubscription(input.text.toString()) }
            .setNeutralButton("دریافت لینک") { _, _ -> fetchSubscription(input.text.toString()) }
            .setNegativeButton("بستن", null).create()
        dlg.show()
    }

    private fun importSubscription(value: String) {
        val parsed = Profile.parseSubscription(value)
        if (parsed.isEmpty()) { toast("کانفیگ معتبری پیدا نشد"); return }
        profiles.clear(); profiles.addAll(parsed); selected = 0; saveProfiles(); refreshServerButton()
        toast("${profiles.size} سرور اضافه شد")
    }

    private fun fetchSubscription(link: String) {
        if (!link.startsWith("https://") && !link.startsWith("http://")) { importSubscription(link); return }
        message.text = "در حال دریافت اشتراک…"
        worker.execute {
            try {
                val c = (URL(link).openConnection() as HttpURLConnection).apply { connectTimeout = 12000; readTimeout = 15000; instanceFollowRedirects = true }
                val body = c.inputStream.bufferedReader().use { it.readText() }; c.disconnect()
                runOnUiThread { importSubscription(body); message.text = "اشتراک پردازش شد." }
            } catch (e: Exception) { runOnUiThread { toast("دریافت ناموفق: ${e.message ?: "خطای شبکه"}"); message.text = "لینک را بررسی کن یا محتوای اشتراک را مستقیم وارد کن." } }
        }
    }

    private fun chooseServer() {
        if (profiles.isEmpty()) { showSettings(); return }
        android.app.AlertDialog.Builder(this).setTitle("سرورها")
            .setSingleChoiceItems(profiles.mapIndexed { i, p -> "${p.name}  (${p.host}:${p.port})${if (i == selected) "  ✓" else ""}" }.toTypedArray(), selected) { dialog, which ->
                if (connected || connecting) { toast("ابتدا اتصال را قطع کن"); dialog.dismiss(); return@setSingleChoiceItems }
                selected = which; refreshServerButton(); dialog.dismiss()
            }.setNegativeButton("بستن", null).show()
    }

    private fun toggleConnection() {
        if (connected || connecting) {
            startService(Intent(this, NativeVpnService::class.java).setAction(NativeVpnService.ACTION_DISCONNECT)); return
        }
        if (profiles.isEmpty()) { showSettings(); return }
        val consent = VpnService.prepare(this)
        if (consent != null) startActivityForResult(consent, REQUEST_VPN) else startVpn()
    }

    @Deprecated("Android VPN consent callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_VPN && resultCode == RESULT_OK) startVpn()
    }

    private fun startVpn() {
        val intent = Intent(this, NativeVpnService::class.java).setAction(NativeVpnService.ACTION_CONNECT)
            .putExtra("config", profiles[selected].config())
            .putExtra("profileName", profiles[selected].name)
            .putExtra("host", profiles[selected].host).putExtra("port", profiles[selected].port)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
    }

    private fun loadProfiles() {
        val raw = prefs.getString("links", "").orEmpty()
        profiles.addAll(Profile.parseSubscription(raw))
        selected = prefs.getInt("selected", 0).coerceIn(0, (profiles.size - 1).coerceAtLeast(0))
    }
    private fun saveProfiles() {
        prefs.edit().putString("links", profiles.joinToString("\n") { it.raw }).putInt("selected", selected).apply()
    }
    private fun refreshServerButton() { serverButton.text = profiles.getOrNull(selected)?.let { "◉  ${it.name}  ⌄" } ?: "انتخاب سرور / افزودن اشتراک" }
    private fun button(label: String, action: () -> Unit) = Button(this).apply { text = label; isAllCaps = false; setTextColor(-1); setBackgroundColor(0xFF1C1C1E.toInt()); setOnClickListener { action() } }
    private fun space(dp: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, this@MainActivity.dp(dp)) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    override fun onDestroy() { try { unregisterReceiver(receiver) } catch (_: Exception) {}; worker.shutdownNow(); super.onDestroy() }

    private fun formatBytes(n: Long): String = when { n < 1024 -> "$n B"; n < 1024*1024 -> "%.1f KB".format(n / 1024.0); n < 1024L*1024*1024 -> "%.1f MB".format(n / (1024.0*1024)); else -> "%.2f GB".format(n / (1024.0*1024*1024)) }
    private fun formatRate(n: Long): String = formatBytes(n)

    companion object { private const val REQUEST_VPN = 1001 }
}

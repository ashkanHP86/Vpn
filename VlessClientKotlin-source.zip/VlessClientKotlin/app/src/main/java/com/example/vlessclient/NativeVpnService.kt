package com.example.vlessclient

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.net.TrafficStats
import java.net.InetSocketAddress
import java.net.Socket
import java.lang.reflect.Proxy
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit
import org.json.JSONObject

/** Owns the Android TUN interface and starts the native sing-box/libbox engine. */
class NativeVpnService : VpnService() {
    private var tunFd: ParcelFileDescriptor? = null
    private var engine: Any? = null
    private var connectedAt = 0L
    private var lastRx = 0L
    private var lastTx = 0L
    private var lastAt = 0L
    private var timer: ScheduledFuture<*>? = null
    private val scheduler = Executors.newSingleThreadScheduledExecutor()
    private var profileName = "VLESS Client"
    private var host = ""
    private var port = 443
    private var statusText = "قطع"

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_DISCONNECT -> stopTunnel()
            ACTION_CONNECT -> {
                val config = intent.getStringExtra("config") ?: return START_NOT_STICKY
                profileName = intent.getStringExtra("profileName") ?: "VLESS Client"
                host = intent.getStringExtra("host") ?: ""
                port = intent.getIntExtra("port", 443)
                startForeground(NOTIFICATION_ID, notification("در حال اتصال به $profileName"))
                Thread { startTunnel(config) }.start()
            }
        }
        return START_STICKY
    }

    private fun startTunnel(config: String) {
        try {
            broadcast(false, true, "در حال راه‌اندازی موتور sing-box…")
            val libbox = Class.forName("io.nekohasekai.libbox.Libbox")
            invokeSetup(libbox)
            val platformClass = Class.forName("io.nekohasekai.libbox.PlatformInterface")
            val platform = Proxy.newProxyInstance(platformClass.classLoader, arrayOf(platformClass)) { proxy, method, args ->
                val name = method.name
                when (name.lowercase()) {
                    "opentun" -> openTun(args?.firstOrNull())
                    "useplatformautodetectinterfacecontrol", "useprocfs", "undernetworkextension", "includeallnetworks", "useplatformshell", "useplatformbridge", "useplatformautoredirect" -> false
                    "autodetectinterfacecontrol", "cleardnscache", "registermyinterface" -> null
                    "findconnectionowner", "localdnstransport", "readwifistate", "lookupsftpserver", "readsystemsshhostkey", "tailscalehostname" -> null
                    "startdefaultinterfacemonitor", "closedefaultinterfacemonitor", "startneighbormonitor", "closeneighbormonitor", "sendnotification", "cancelnotification", "checkplatformshell" -> null
                    "getinterfaces" -> emptyIteratorProxy(method.returnType)
                    else -> defaultValue(method.returnType)
                }
            }
            val create = libbox.methods.firstOrNull { it.name == "newService" && it.parameterTypes.size == 2 }
                ?: error("نسخه libbox نصب‌شده API موردنیاز را ندارد")
            val newEngine = create.invoke(null, config, platform) ?: error("ساخت موتور sing-box ناموفق بود")
            engine = newEngine
            newEngine.javaClass.methods.firstOrNull { it.name.equals("start", true) && it.parameterTypes.isEmpty() }
                ?.invoke(newEngine) ?: run {
                    if (newEngine.javaClass.methods.none { it.name.equals("start", true) && it.parameterTypes.isEmpty() }) error("متد start در libbox پیدا نشد")
                }
            connectedAt = System.currentTimeMillis()
            lastAt = connectedAt
            lastRx = TrafficStats.getUidRxBytes(android.os.Process.myUid()).coerceAtLeast(0)
            lastTx = TrafficStats.getUidTxBytes(android.os.Process.myUid()).coerceAtLeast(0)
            statusText = "متصل"
            broadcast(true, false, "متصل به $profileName")
            startStats()
        } catch (e: Throwable) {
            val cause = e.cause ?: e
            statusText = "خطا در اتصال"
            broadcast(false, false, "خطای موتور: ${cause.message ?: cause.javaClass.simpleName}")
            stopTunnel(stopSelf = true)
        }
    }

    private fun invokeSetup(libbox: Class<*>) {
        val setup = libbox.methods.firstOrNull { it.name.equals("setup", true) } ?: return
        val args = setup.parameterTypes.mapIndexed { i, type ->
            when {
                type == String::class.java -> if (i == 0) filesDir.absolutePath else cacheDir.absolutePath
                type == Boolean::class.javaPrimitiveType || type == Boolean::class.javaObjectType -> false
                type == Int::class.javaPrimitiveType || type == Int::class.javaObjectType -> 0
                else -> null
            }
        }.toTypedArray()
        setup.invoke(null, *args)
    }

    private fun openTun(options: Any?): Int {
        val builder = Builder().setSession(profileName).setMtu(readInt(options, "getMtu", "getMTU").takeIf { it in 576..9000 } ?: 1500)
        val v4 = readStrings(options, "getInet4Address", "getInet4Addresses")
        val v6 = readStrings(options, "getInet6Address", "getInet6Addresses")
        v4.forEach { cidr -> addAddress(builder, cidr) }
        v6.forEach { cidr -> addAddress(builder, cidr) }
        if (v4.isEmpty() && v6.isEmpty()) builder.addAddress("172.19.0.1", 30)
        builder.addDnsServer("1.1.1.1")
        // Full-tunnel routes. The sing-box TUN inbound owns packet processing and routing.
        builder.addRoute("0.0.0.0", 0)
        try { builder.addRoute("::", 0) } catch (_: Exception) { }
        builder.setBlocking(false)
        tunFd?.close()
        tunFd = builder.establish() ?: error("Android اجازه ساخت رابط VPN را نداد")
        return tunFd!!.fd
    }

    private fun addAddress(builder: Builder, cidr: String) {
        val parts = cidr.split("/")
        if (parts.size != 2) return
        val prefix = parts[1].toIntOrNull() ?: return
        try { builder.addAddress(parts[0], prefix) } catch (_: Exception) { }
    }

    private fun readInt(obj: Any?, vararg methods: String): Int {
        if (obj == null) return 0
        for (name in methods) try { return (obj.javaClass.methods.first { it.name == name && it.parameterTypes.isEmpty() }.invoke(obj) as Number).toInt() } catch (_: Exception) { }
        return 0
    }

    private fun readStrings(obj: Any?, vararg methods: String): List<String> {
        if (obj == null) return emptyList()
        for (name in methods) try {
            val value = obj.javaClass.methods.first { it.name == name && it.parameterTypes.isEmpty() }.invoke(obj) ?: continue
            val result = mutableListOf<String>()
            if (value is Iterable<*>) return value.filterIsInstance<String>()
            val hasNext = value.javaClass.methods.firstOrNull { it.name.equals("hasNext", true) && it.parameterTypes.isEmpty() }
            val next = value.javaClass.methods.firstOrNull { it.name.equals("next", true) && it.parameterTypes.isEmpty() }
            if (hasNext != null && next != null) {
                var guard = 0
                while ((hasNext.invoke(value) as? Boolean == true) && guard++ < 128) result += next.invoke(value).toString()
                return result
            }
        } catch (_: Exception) { }
        return emptyList()
    }

    private fun emptyIteratorProxy(type: Class<*>): Any? {
        if (!type.isInterface) return null
        return Proxy.newProxyInstance(type.classLoader, arrayOf(type)) { _, method, _ ->
            when (method.name.lowercase()) { "hasnext" -> false; "next" -> null; else -> defaultValue(method.returnType) }
        }
    }

    private fun defaultValue(type: Class<*>): Any? = when (type) {
        java.lang.Boolean.TYPE -> false
        java.lang.Integer.TYPE, java.lang.Short.TYPE, java.lang.Byte.TYPE -> 0
        java.lang.Long.TYPE -> 0L
        java.lang.Float.TYPE -> 0f
        java.lang.Double.TYPE -> 0.0
        else -> null
    }

    private fun startStats() {
        timer?.cancel(false)
        timer = scheduler.scheduleAtFixedRate({
            val now = System.currentTimeMillis()
            val rx = TrafficStats.getUidRxBytes(android.os.Process.myUid()).coerceAtLeast(0)
            val tx = TrafficStats.getUidTxBytes(android.os.Process.myUid()).coerceAtLeast(0)
            val elapsed = (now - lastAt).coerceAtLeast(1)
            val rxRate = ((rx - lastRx).coerceAtLeast(0) * 1000L) / elapsed
            val txRate = ((tx - lastTx).coerceAtLeast(0) * 1000L) / elapsed
            lastAt = now; lastRx = rx; lastTx = tx
            val seconds = ((now - connectedAt) / 1000).toInt().coerceAtLeast(0)
            val time = "%02d:%02d:%02d".format(seconds / 3600, seconds / 60 % 60, seconds % 60)
            broadcast(true, false, "متصل به $profileName", rx, tx, rxRate, txRate, time)
        }, 0, 1, TimeUnit.SECONDS)
    }

    private fun probeTcp(): String {
        if (host.isBlank()) return "TCP latency: —"
        val start = System.nanoTime()
        return try { Socket().use { it.connect(InetSocketAddress(host, port), 2500) }; "TCP latency: ${((System.nanoTime() - start) / 1_000_000).coerceAtLeast(1)} ms" }
        catch (_: Exception) { "TCP latency: timeout" }
    }

    private fun broadcast(isConnected: Boolean, isConnecting: Boolean, status: String, rx: Long = 0, tx: Long = 0, rxRate: Long = 0, txRate: Long = 0, elapsed: String = "00:00:00") {
        val ping = if (isConnected) probeTcp() else "TCP latency: —"
        sendBroadcast(Intent(EVENT).setPackage(packageName)
            .putExtra("connected", isConnected).putExtra("connecting", isConnecting)
            .putExtra("status", status).putExtra("rx", rx).putExtra("tx", tx)
            .putExtra("rxRate", rxRate).putExtra("txRate", txRate)
            .putExtra("elapsed", elapsed).putExtra("ping", ping))
        if (isConnected || isConnecting) getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, notification(status))
    }

    private fun stopTunnel(stopSelf: Boolean = true) {
        timer?.cancel(false); timer = null
        try { engine?.javaClass?.methods?.firstOrNull { it.name.equals("close", true) && it.parameterTypes.isEmpty() }?.invoke(engine) } catch (_: Exception) { }
        engine = null
        try { tunFd?.close() } catch (_: Exception) { }; tunFd = null
        statusText = "قطع"
        broadcast(false, false, "قطع")
        if (Build.VERSION.SDK_INT >= 24) {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } else {
            @Suppress("DEPRECATION")
            stopForeground(true)
        }
        if (stopSelf) stopSelf()
    }

    private fun notification(text: String): Notification {
        val manager = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(NotificationChannel(CHANNEL, "VPN connection", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL)
            .setContentTitle("VLESS Client").setContentText(text).setSmallIcon(android.R.drawable.stat_sys_warning).setContentIntent(open).setOngoing(true).build()
        else @Suppress("DEPRECATION") Notification.Builder(this).setContentTitle("VLESS Client").setContentText(text).setSmallIcon(android.R.drawable.stat_sys_warning).setContentIntent(open).setOngoing(true).build()
    }

    override fun onDestroy() { stopTunnel(stopSelf = false); scheduler.shutdownNow(); super.onDestroy() }

    companion object {
        const val EVENT = "com.example.vlessclient.VPN_EVENT"
        const val ACTION_CONNECT = "com.example.vlessclient.CONNECT"
        const val ACTION_DISCONNECT = "com.example.vlessclient.DISCONNECT"
        private const val CHANNEL = "vless_vpn"
        private const val NOTIFICATION_ID = 701
    }
}
